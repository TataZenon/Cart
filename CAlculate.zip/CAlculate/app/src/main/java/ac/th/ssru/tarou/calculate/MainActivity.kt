package ac.th.ssru.tarou.calculate

import ac.th.ssru.tarou.calculate.PageDetailActivity.Companion.DETAIL_KEY
import ac.th.ssru.tarou.calculate.PageDetailActivity.Companion.IMAGE_KEY
import ac.th.ssru.tarou.calculate.PageDetailActivity.Companion.TITLE_KEY
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

class MainActivity : AppCompatActivity(), View.OnClickListener {
    var llImg1: LinearLayout? = null
    var llImg2: LinearLayout? = null
    var llImg3: LinearLayout? = null
    var llImg4: LinearLayout? = null
    var llImg5: LinearLayout? = null
    var llImg6: LinearLayout? = null
    var llImg7: LinearLayout? = null
    var llImg8: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sample_basic_layout)

        bindView()
        initView()
    }

    private fun initView() {
        llImg1?.setOnClickListener(this)
        llImg2?.setOnClickListener(this)
        llImg3?.setOnClickListener(this)
        llImg4?.setOnClickListener(this)
        llImg5?.setOnClickListener(this)
        llImg6?.setOnClickListener(this)
        llImg7?.setOnClickListener(this)
        llImg8?.setOnClickListener(this)
    }

    private fun bindView() {
        llImg1 = findViewById(R.id.llImg1)
        llImg2 = findViewById(R.id.llImg2)
        llImg3 = findViewById(R.id.llImg3)
        llImg4 = findViewById(R.id.llImg4)
        llImg5 = findViewById(R.id.llImg5)
        llImg6 = findViewById(R.id.llImg6)
        llImg7 = findViewById(R.id.llImg7)
        llImg8 = findViewById(R.id.llImg8)


    }

    override fun onClick(v: View?) {
        when (v) {
            llImg1 -> {(onOpenPageDetail(R.drawable.junk, R.string.str_title1, R.string.str_detail1))}
            llImg2 -> {(onOpenPageDetail(R.drawable.lu, R.string.str_title2, R.string.str_detail2))}
            llImg3 -> {(onOpenPageDetail(R.drawable.mei, R.string.str_title3, R.string.str_detail3))}
            llImg4 -> {(onOpenPageDetail(R.drawable.mer, R.string.str_title4, R.string.str_detail4))}
            llImg5 -> {(onOpenPageDetail(R.drawable.moi, R.string.str_title5, R.string.str_detail5))}
            llImg6 -> {(onOpenPageDetail(R.drawable.ori, R.string.str_title6, R.string.str_detail6))}
            llImg7 -> {(onOpenPageDetail(R.drawable.rea, R.string.str_title7, R.string.str_detail7))}
            llImg8 -> {(onOpenPageDetail(R.drawable.rein, R.string.str_title8, R.string.str_detail8))}
        }

    }

    private fun onOpenPageDetail(@DrawableRes resImage: Int, @StringRes resTitle: Int, @StringRes resDetail: Int) {
        val intent: Intent = Intent(this, PageDetailActivity::class.java)
        intent.putExtra(IMAGE_KEY, resImage)
        intent.putExtra(TITLE_KEY, resTitle)
        intent.putExtra(DETAIL_KEY, resDetail)
        startActivity(intent)
    }
}