package ac.th.ssru.tarou.calculate

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PageDetailActivity: AppCompatActivity() {
    var resImage: Int? = 0
    var resTitle: Int? =0
    var resDetail: Int? =0

    var ivImage: ImageView? = null
    var tvTitle: TextView? = null
    var tvDetail: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_detail)

        getData()
        bindView()
        initView()
    }

    private fun initView() {
        ivImage?.setImageResource(resImage!!)
        tvTitle?.setText(resTitle!!)
        tvDetail?.setText(resDetail!!)

    }

    private fun bindView() {
        ivImage = findViewById(R.id.ivImage)
        tvTitle = findViewById(R.id.tvTitle)
        tvDetail = findViewById(R.id.tvDetail)

    }

    private fun getData() {
        val arge = intent.extras
        resImage = arge?.getInt(IMAGE_KEY, R.drawable.junk)
        resTitle = arge?.getInt(TITLE_KEY, R.string.str_title1)
        resDetail = arge?.getInt(DETAIL_KEY, R.string.str_detail1)

    }

    companion object {
        const val  IMAGE_KEY:String = "image"
        const val  TITLE_KEY:String = "title"
        const val  DETAIL_KEY:String = "detail"
    }

}